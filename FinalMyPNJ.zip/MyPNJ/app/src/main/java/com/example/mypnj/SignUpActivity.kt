package com.example.mypnj

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_sign_up.*

class SignUpActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        btn_signlogin.setOnClickListener {
            onBackPressed()
        }

        auth = FirebaseAuth.getInstance()

        btn_signup.setOnClickListener {
            val email = edtemail.text.toString().trim()
            val password = edtpassword.text.toString().trim()
            val fullname = edtname.text.toString().trim()

            if (email.isEmpty()) {
                edtemail.error = "Email harus diisi"
                edtemail.requestFocus()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                edtemail.error = "Alamat email tidak valid"
                edtemail.requestFocus()
                return@setOnClickListener
            }

            if (password.isEmpty() || password.length < 6) {
                edtpassword.error = "Password harus lebih dari 6 karakter"
                edtpassword.requestFocus()
                return@setOnClickListener
            }

            if (fullname.isEmpty()) {
                edtname.error = "Nama harus diisi"
                edtname.requestFocus()
                return@setOnClickListener
            }

            registerUser(email, password)
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right)
    }


    private fun registerUser(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) {
                if (it.isSuccessful) {
                    Intent(this@SignUpActivity, HomeActivity::class.java).also {
                        it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(it)
                    }
                } else {
                    Toast.makeText(this, it.exception?.message, Toast.LENGTH_SHORT).show()
                }
            }
        }


    override fun onStart() {
        super.onStart()
        if (auth.currentUser != null) {
            Intent(this@SignUpActivity, HomeActivity::class.java).also {
                it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(it)
            }
        }
    }
}
