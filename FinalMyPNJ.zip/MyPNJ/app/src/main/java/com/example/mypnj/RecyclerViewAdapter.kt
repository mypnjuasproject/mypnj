package com.example.mypnj

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.recyclerview_model.view.*

class RecyclerViewAdapter : RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>(){


    private val itemTitles = arrayOf(
        "Teknik Mesin","Teknik Elektro","Teknik Sipil","Akutansi","Administrasi Bisnis(Niaga)","Teknik Grafika dan Penerbitan",
        "Teknik Informatika dan Komputer")

    private val itemDetails = arrayOf(
        "Jurusan Teknik Mesin, Politeknik Negeri Jakarta menyiapkan mahasiswa agar menjadi lulusan yang memiliki kompetensi pada bidang tenaga ahli menengah profesional dan kompeten yang mampu mengisi posisi penyelia atau pelaksana dalam industri manufaktur, pembangit tenaga listrik, audit energi, dan optimasi serta perawatan alat berat, fasilitas industri semen,  perawatan kilang gas, pesawat udara, dan falititas peralatan mekanik lainnya.",
        "Mengupayakan 100 % mahasiswa lulus tepat waktu.\n" +
                "Mengupayakan 100 % lulusan terserap pasar kerja global dengan masa tunggu 0 bulan.\n" +
                "Mengupayakan 50 % lulusan menjadi wirausaha.\n" +
                "Mengupayakan lulusan memiliki sertifikat kompetensi keahlian dibidang teknik instrumentasi dan kontrol.\n" +
                "Mengupayakan hasil penelitian terpublikasi ditingkat global.\n" +
                "Melakukan kerjasama dengan industri berskala nasional dan internasional.",
        "Jurusan Teknik Sipil menyiapkan mahasiswa menjadi tenaga ahli menengah profesional dan kompeten, yang mampu mengisi posisi penyelia atau pelaksanan dalam industri konstruksi dengan spesifikasi konstruksi bangunan gedung, bangunan sipil, manajemen konstruksi bangunan gedung serta jalan dan jembatan.",
        "Jurusan Akuntansi didirikan untuk menghasilkan tenaga ahli madya profesional dan kompeten dalam bidang akuntansi serta bidang keuangan dan perbankan baik konvensional maupun syariah. Jurusan Akuntansi mendidik dan menghasilkan tenaga siap kerja yang akan mengisi posisi pelaksana dan atau penyelia pada berbagai macam industri. Jurusan Akuntansi menyelenggarakan enam program studi yaitu, D-3 Akuntansi, D-3 Keuangan Perbankan, dan S-1 Terapan Keuangan Perbankan Syariah, S-1 Terapan Akuntansi, dan S-1 Terapan Keuangan dan Perbankan, dan S-1 Terapan Manajemen Keuangan",
        "Sesuai perkembangan dan kebutuhan industri yang semakin beragam, pada tahun 1986, Politeknik UI membuka Jurusan Tata Niaga dengan 3 program studi(prodi), yaitu: Akuntansi, Perbankan dan Administrasi Niaga. Setelah berjalan 6 tahun, berdasarkan SK Mendikbud No. 1013/O/1991 tentang Penataan Politeknik dalam lingkungan Universitas dan institut negeri, kemudian pada tahun 1992, jurusan Tata Niaga dipisah menjadi 2 jurusan yaitu, Jurusan Administrasi Niaga, dengan Program studi D3 Kesekretariatan dan Administrasi Perkantoran(SK Dirjen Dikti No. 45/DIKTI/Kep/2001 menjadi prodi: Administrasi Bisnis) dan Jurusan Akuntansi, dengan Prodi D3 Akuntansi dan D3 Keuangan Perbankan.",
        "Jurusan Teknik Grafika dan Penerbitan berdiri tahun 1990, menyiapkan sumber daya manusia menjadi tenaga ahli menengah profesional dan kompeten yang mampu mengisi posisi penyelia atau pelaksana dalam bidang grafika, penerbitan, desain grafis, dan teknologi industri cetak kemasan. Jurusan Teknik Gradika dan Penerbitan menyelenggarakan empat program studi,D-3 Teknik Grafika, D-3 Penerbitan/Jurnalistik, D-4 Desain Grafis, dan D-4 Teknologi Industri Cetak Kemasan",
        "Jurusan Teknik Informatika dan Komputer (TIK) diresmikan pada 2 Juni 2014 yang bertujuan untuk menghasilkan lulusan sarjana sains terapan yang berpengalaman dan mampu memecahkan masalah dalam bidang Teknik Informatika dan Komputer dengan menganalisis, merancang dan membangun sistem.")

    private val itemImages = intArrayOf(
        R.drawable.maskmesin,
        R.drawable.maskelektro,
        R.drawable.masksipil,
        R.drawable.maskakutansi,
        R.drawable.maskan,
        R.drawable.masktgp,
        R.drawable.masktik
    )

    inner class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView){

        var image : ImageView
        var textTitle : TextView
        var textDes : TextView

        init {
            image = itemView.findViewById(R.id.item_image)
            textTitle = itemView.findViewById(R.id.item_title)
            textDes = itemView.findViewById(R.id.item_details)
        }


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v  = LayoutInflater.from(parent.context)
            .inflate(R.layout.recyclerview_model,parent, false)
        return ViewHolder(v)

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.textTitle.text = itemTitles [position]
        holder.textDes.text = itemDetails [position]
        holder.image.setImageResource(itemImages[position])

        holder.itemView.setOnClickListener {v: View ->

            Toast.makeText(v.context, "Clicked on the item", Toast.LENGTH_SHORT ).show()

        }
    }
    override fun getItemCount(): Int {
        return itemTitles.size

    }
}

