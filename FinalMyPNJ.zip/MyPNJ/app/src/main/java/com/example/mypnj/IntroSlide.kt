package com.example.mypnj

data class IntroSlide(
    val title: String,
    val description: String?,
    val icon: Int

)