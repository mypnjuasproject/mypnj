package com.example.mypnj

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_kegiatan_mahasiswa.*

class KegiatanMahasiswa : AppCompatActivity() {

    private var listView: ListView? = null
    private var cAdapter: ListView_ukm_adapter? = null
    private var imageArrayList: ArrayList<ListView_ukm_model>? = null

    private var ukmImage = intArrayOf(R.drawable.m, R.drawable.b, R.drawable.h, R.drawable.h, R.drawable.h, R.drawable.h, R.drawable.h, R.drawable.h,
        R.drawable.s, R.drawable.b, R.drawable.b, R.drawable.b, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u,
        R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u, R.drawable.u,
        R.drawable.k, R.drawable.k, R.drawable.k, R.drawable.k, R.drawable.k, R.drawable.k, R.drawable.k)
    private var ukmName = arrayOf("Majelis Permusyawaratan Mahasiswa(MPM)","Badan Eksekutif Mahasiswa(BEM)","Himpunan Mahasiswa Sipil(HMS)",
        "Himpunan Mahasiswa Mesin(HMM)", "Himpunan Mahasiswa Elektro(HME)","Himpunan Mahasiswa Jurusan Akutansi(HMIA)",
    "Himpunan Mahasiswa Administrasi Niaga(HMAN)","Himpunan Mahasiswa Teknik Grafika dan Penerbitan","Senat Mahasiswa Program Khusus(HMM)",
        "BO Astadeca","BO Kopma Adil PNJ","BO Gema","UKM Polytechnic English Club(PEC)","UKM Pesoet","UKM Basket(Pocket)","UKM Taekwondo","UKM Badminton/Bulu Tangkis",
        "UKM Volly(POLVOC)","UKM Radio(POROS FM 94.15)","UKM Catur","UKM Korp.Latih Mahasiswa","UKM Ansos","UKM Fikri","UKM Teknis Meja(POTTEC)",
        "UKM Hikmatul Iman","UKM Pankreas","UKM Mars Project","UKM Pramuka","UKM Logika (dalam masa pembekuan)","KSM Psycorobotic",
        "KSM Energi","KSM Sahabat PNJ","KSM CMSS","KSM Comic Club","KSM Mobil Listrik","KSM Alat Berat"
    )


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kegiatan_mahasiswa)


        listView = findViewById(R.id.listView_ukm) as ListView
        imageArrayList = fun_PopulateList()

        cAdapter = ListView_ukm_adapter(this, imageArrayList!!)
        listView!!.adapter = cAdapter




    }
    private fun fun_PopulateList (): ArrayList<ListView_ukm_model> {
        val list = java.util.ArrayList<ListView_ukm_model> ()
        for(i in 0..35) {
            val imageModel = ListView_ukm_model()
            imageModel.setImage(ukmImage[i])
            imageModel.setNames(ukmName[i])
            list.add(imageModel)
        }
        return list
    }
}
