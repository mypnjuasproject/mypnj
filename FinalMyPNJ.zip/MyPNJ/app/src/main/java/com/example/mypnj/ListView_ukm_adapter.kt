package com.example.mypnj

import android.content.Context
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.getSystemService
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.list_view_model.view.*

class ListView_ukm_adapter
    (private val context: Context,
     private val ListViewArrayList: ArrayList<ListView_ukm_model>) : BaseAdapter() {


    override fun getViewTypeCount(): Int {
        return count
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun getCount(): Int {
        return ListViewArrayList.size
    }

    override fun getItem(position: Int): Any {
        return ListViewArrayList[position]
    }

    override fun getItemId(position: Int): Long {
        return 0

    }

    override fun getView(position: Int, itemView: View?, parent: ViewGroup?): View {
        var itemView= itemView
        val holder: ViewHolder

        if (itemView == null) {
            holder = ViewHolder()
            val inflater = context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            itemView = inflater.inflate(R.layout.list_view_model, null, true)

            holder.name = itemView!!.findViewById(R.id.name) as TextView
            holder.iv = itemView.findViewById(R.id.imgView) as ImageView

            itemView.tag = holder

        }
        else {
            holder = itemView.tag as ViewHolder
        }

        holder.name!!.setText(ListViewArrayList[position].getNames())
        holder.iv!!.setImageResource(ListViewArrayList[position].getImage())

        //Item CLicked Action
        holder.name!!.setOnClickListener { v: View ->
            Toast.makeText(v.getContext(), "Clicked on the item.", Toast.LENGTH_SHORT).show();
        }
        return itemView

        }
    private inner class ViewHolder{
        var name: TextView? = null
        internal var iv: ImageView? = null
    }
    }

