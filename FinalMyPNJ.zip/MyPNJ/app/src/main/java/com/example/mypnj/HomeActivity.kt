package com.example.mypnj

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth


class HomeActivity : AppCompatActivity(), View.OnClickListener{
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        auth = FirebaseAuth.getInstance()

        val btnsejarahActivity: ImageButton= findViewById(R.id.btn_sejarah)
        btnsejarahActivity.setOnClickListener(this)

        val btnjurusanActivity :ImageButton= findViewById(R.id.btn_jurusan)
        btnjurusanActivity.setOnClickListener(this)

        val btnkegiatanmahasiswaActivity :ImageButton= findViewById(R.id.btn_kegiatanmahasiswa)
        btnkegiatanmahasiswaActivity.setOnClickListener(this)

        val btnprestasiActivity :ImageButton= findViewById(R.id.btn_prestasi)
        btnprestasiActivity.setOnClickListener(this)

        val btnfounderActivity :ImageButton= findViewById(R.id.btn_founder)
        btnfounderActivity.setOnClickListener(this)

        val btnMapsActivity : ImageButton = findViewById(R.id.btn_map)
        btnMapsActivity.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_sejarah -> {
                val sejarahIntent = Intent(this@HomeActivity, SejarahActivity::class.java)
                startActivity(sejarahIntent)
            }

            R.id.btn_jurusan -> {
                val jurusanIntent = Intent(this@HomeActivity, JurusanActivity::class.java)
                startActivity(jurusanIntent)
            }
            R.id.btn_kegiatanmahasiswa -> {
                val kegiatanmahasiswaIntent = Intent(this@HomeActivity, KegiatanMahasiswa::class.java)
                startActivity(kegiatanmahasiswaIntent)
            }
            R.id.btn_prestasi -> {
                val prestasiIntent = Intent(this@HomeActivity, PrestasiActivity::class.java)
                startActivity(prestasiIntent)
            }
            R.id.btn_founder -> {
                val founderIntent = Intent(this@HomeActivity, FounderActivity::class.java)
                startActivity(founderIntent)
            }
            R.id.btn_map -> {
                val mapIntent = Intent(this@HomeActivity, MapsActivity::class.java)
                startActivity(mapIntent)
            }
        }


    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.btn_logout ->{
                auth.signOut()
                Intent(this@HomeActivity,LoginActivity::class.java).also {
                    it.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(it)
                }
                return true
            }
            else -> return true
        }
    }
    }

